-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: osg.raam.ro    Database: nobrain_middleware
-- ------------------------------------------------------
-- Server version	5.5.62-0ubuntu0.14.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `NEWS`
--

DROP TABLE IF EXISTS `NEWS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `NEWS` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `news` mediumtext NOT NULL,
  `dateAjout` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `NEWS`
--

LOCK TABLES `NEWS` WRITE;
/*!40000 ALTER TABLE `NEWS` DISABLE KEYS */;
/*!40000 ALTER TABLE `NEWS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `activeCode`
--

DROP TABLE IF EXISTS `activeCode`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `activeCode` (
  `idClient` int(11) NOT NULL,
  `numberCode` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `duree` varchar(255) NOT NULL,
  `active` int(11) NOT NULL,
  PRIMARY KEY (`idClient`),
  UNIQUE KEY `numberCode_UNIQUE` (`numberCode`),
  UNIQUE KEY `username_UNIQUE` (`username`),
  CONSTRAINT `FK_IDUSRES1` FOREIGN KEY (`idClient`) REFERENCES `xtream_iptvpro`.`users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activeCode`
--

LOCK TABLES `activeCode` WRITE;
/*!40000 ALTER TABLE `activeCode` DISABLE KEYS */;
/*!40000 ALTER TABLE `activeCode` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `enigmaLine`
--

DROP TABLE IF EXISTS `enigmaLine`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `enigmaLine` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idline` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idline_UNIQUE` (`idline`),
  KEY `FK_idlinee` (`idline`),
  CONSTRAINT `FK_idlinee` FOREIGN KEY (`idline`) REFERENCES `xtream_iptvpro`.`users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `enigmaLine`
--

LOCK TABLES `enigmaLine` WRITE;
/*!40000 ALTER TABLE `enigmaLine` DISABLE KEYS */;
/*!40000 ALTER TABLE `enigmaLine` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `infolines`
--

DROP TABLE IF EXISTS `infolines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `infolines` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idlines` int(11) NOT NULL,
  `firstname` varchar(255) DEFAULT NULL,
  `familyname` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `limitchangeact` int(11) DEFAULT '0',
  `limitpauseact` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idlines_UNIQUE` (`idlines`),
  KEY `FK_IDLINES` (`idlines`),
  CONSTRAINT `FK_IDLINES` FOREIGN KEY (`idlines`) REFERENCES `xtream_iptvpro`.`users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `infolines`
--

LOCK TABLES `infolines` WRITE;
/*!40000 ALTER TABLE `infolines` DISABLE KEYS */;
/*!40000 ALTER TABLE `infolines` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inforeseller`
--

DROP TABLE IF EXISTS `inforeseller`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inforeseller` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idreg` int(11) NOT NULL,
  `fristname` mediumtext,
  `familyname` mediumtext,
  `phone` mediumtext,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idreg_UNIQUE` (`idreg`),
  KEY `FK_IDREG1` (`idreg`),
  CONSTRAINT `FK_IDREG1` FOREIGN KEY (`idreg`) REFERENCES `xtream_iptvpro`.`reg_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inforeseller`
--

LOCK TABLES `inforeseller` WRITE;
/*!40000 ALTER TABLE `inforeseller` DISABLE KEYS */;
/*!40000 ALTER TABLE `inforeseller` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ipActiveCode`
--

DROP TABLE IF EXISTS `ipActiveCode`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ipActiveCode` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `activecode` mediumtext NOT NULL,
  `ip` mediumtext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ipActiveCode`
--

LOCK TABLES `ipActiveCode` WRITE;
/*!40000 ALTER TABLE `ipActiveCode` DISABLE KEYS */;
/*!40000 ALTER TABLE `ipActiveCode` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `resellerOffer`
--

DROP TABLE IF EXISTS `resellerOffer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `resellerOffer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idRev` int(11) NOT NULL,
  `listPackage` mediumtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_PACKAGEREV` (`idRev`),
  CONSTRAINT `FK_PACKAGEREV` FOREIGN KEY (`idRev`) REFERENCES `xtream_iptvpro`.`reg_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `resellerOffer`
--

LOCK TABLES `resellerOffer` WRITE;
/*!40000 ALTER TABLE `resellerOffer` DISABLE KEYS */;
/*!40000 ALTER TABLE `resellerOffer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `revendeurAccount`
--

DROP TABLE IF EXISTS `revendeurAccount`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `revendeurAccount` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idRev` int(11) NOT NULL,
  `idPackage` int(11) NOT NULL,
  `totalAccount` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_IDREV2` (`idRev`),
  CONSTRAINT `FK_IDREV2` FOREIGN KEY (`idRev`) REFERENCES `xtream_iptvpro`.`reg_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `revendeurAccount`
--

LOCK TABLES `revendeurAccount` WRITE;
/*!40000 ALTER TABLE `revendeurAccount` DISABLE KEYS */;
/*!40000 ALTER TABLE `revendeurAccount` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `revendeurLimit`
--

DROP TABLE IF EXISTS `revendeurLimit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `revendeurLimit` (
  `idReg` int(11) NOT NULL,
  `Months12` int(11) NOT NULL,
  `Months6` int(11) NOT NULL,
  `Months1` int(11) NOT NULL,
  `Days1` int(11) NOT NULL,
  `SD12` int(11) NOT NULL,
  `SD6` int(11) NOT NULL,
  `SD1` int(11) NOT NULL,
  `SDAYS1` int(11) NOT NULL,
  `EMonths12` int(11) NOT NULL,
  `EDAYS1` int(11) NOT NULL,
  `Months3` int(11) NOT NULL,
  `SMonths3` int(11) NOT NULL,
  PRIMARY KEY (`idReg`),
  CONSTRAINT `FK_IDREG` FOREIGN KEY (`idReg`) REFERENCES `xtream_iptvpro`.`reg_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `revendeurLimit`
--

LOCK TABLES `revendeurLimit` WRITE;
/*!40000 ALTER TABLE `revendeurLimit` DISABLE KEYS */;
/*!40000 ALTER TABLE `revendeurLimit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `revendeurcounter`
--

DROP TABLE IF EXISTS `revendeurcounter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `revendeurcounter` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idRev` int(11) NOT NULL,
  `numAct` int(11) NOT NULL DEFAULT '0',
  `numStop` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `FK_IDREVV` (`idRev`),
  CONSTRAINT `FK_IDREVV` FOREIGN KEY (`idRev`) REFERENCES `xtream_iptvpro`.`reg_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `revendeurcounter`
--

LOCK TABLES `revendeurcounter` WRITE;
/*!40000 ALTER TABLE `revendeurcounter` DISABLE KEYS */;
/*!40000 ALTER TABLE `revendeurcounter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nameServer` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `logo` varchar(255) NOT NULL,
  `facebookpage` varchar(255) DEFAULT NULL,
  `xtreampage` varchar(255) DEFAULT NULL,
  `twitterpage` varchar(255) DEFAULT NULL,
  `instagrampage` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES (1,'Panel Fibonacci Group','','','','','','');
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stableTV`
--

DROP TABLE IF EXISTS `stableTV`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stableTV` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_str` int(11) NOT NULL,
  `dateON` int(11) DEFAULT NULL,
  `dateOFF` int(11) NOT NULL,
  `lastupdate` int(11) DEFAULT NULL,
  `numberupdate` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_str_UNIQUE` (`id_str`),
  KEY `FK_IDSTR14` (`id_str`),
  CONSTRAINT `FK_IDSTR14` FOREIGN KEY (`id_str`) REFERENCES `xtream_iptvpro`.`streams` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stableTV`
--

LOCK TABLES `stableTV` WRITE;
/*!40000 ALTER TABLE `stableTV` DISABLE KEYS */;
/*!40000 ALTER TABLE `stableTV` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'nobrain_middleware'
--

--
-- Dumping routines for database 'nobrain_middleware'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-11-30  4:18:10
