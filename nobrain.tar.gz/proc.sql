--
-- Dumping routines for database 'nobrain_middleware'
--

USE `xtream_iptvpro`;

/*!50003 DROP PROCEDURE IF EXISTS `addUsers` */;
ALTER DATABASE `nobrain_middleware` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `addUsers`(
memberid_in INT,
username_in varchar(255),
bouquet_in varchar(255),
reguserid_in INT,
ismag_in INT,
duree_in VARCHAR(255),
firstname_in varchar(255),
familyname_in varchar(255),
phonenumber_in varchar(255)
)
BEGIN
INSERT INTO users (
                                                                    `member_id`,
                                                                      `username`,
                                                                    `password`,
                                                                    `exp_date`,
                                                                    `admin_enabled`,
                                                                    `enabled`,
                                                                    `admin_notes`,
                                                                    `reseller_notes`,
                                                                    `bouquet`,
                                                                    `max_connections`,
  `is_restreamer`,
  `allowed_ips`,
  `allowed_ua`,
  `is_trial`,
  `created_at`,
  `created_by`,
  `pair_id`,
  `is_mag`,
  `force_server_id`,
  `is_isplock`,
  `isp_desc`,
  `forced_country`,
  `is_stalker`,
  `bypass_ua`
)
VALUES
  (
    memberid_in,
    username_in,
    LEFT (UUID(), 8),
    NULL,
    1,
    0,
    '',
    '',
    bouquet_in,
    1,
    0,
    '[]',
    '[]',
    0,
    UNIX_TIMESTAMP(CURRENT_TIMESTAMP()),
    reguserid_in,
    NULL,
    ismag_in,
    0,
    0,
    '',
    '',
    0,
    0
  );
  
  UPDATE nobrain_middleware.activeCode
  SET duree=duree_in
  WHERE username=username_in;
  
  INSERT INTO 
	nobrain_middleware.infolines(idlines, firstname, familyname, phone)
  VALUES
	(ReturnIDREG(username_in),firstname_in,familyname_in,phonenumber_in);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `nobrain_middleware` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `getAllInactiveLine` */;
ALTER DATABASE `nobrain_middleware` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `getAllInactiveLine`(
ruid_int INT
)
BEGIN
		SELECT
     case
	WHEN uan.activity_id IS NOT NULL THEN 'ON'
    WHEN uan.activity_id IS NULL THEN 'OFF'
  end AS linestate,
  case
	WHEN us.enabled=0 THEN 'DISABLED'
    WHEN us.enabled=1 THEN 'ENABLED'
  end AS state,
  infL.firstname,
  infL.familyname,
  infL.phone,
 act.numberCode AS ActiveCode,
  upper(act.duree),
  us.id
FROM
  users us
LEFT JOIN user_activity_now uan ON uan.user_id=us.id
INNER JOIN reg_users ru ON ru.id = us.member_id && ru.id = ruid_int && us.is_mag=0
LEFT JOIN nobrain_middleware.activeCode act
	ON act.idClient=us.id
LEFT JOIN
	nobrain_middleware.infolines infL
		ON infL.idlines=act.idClient
WHERE  act.active=0
GROUP BY us.id
ORDER BY us.created_at DESC;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `nobrain_middleware` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `getAllNews` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `getAllNews`()
BEGIN
	SELECT
		nw.id,
        nw.news,
        nw.dateAjout
	FROM
		NEWS nw
	ORDER BY
		from_unixtime(nw.dateAjout) DESC;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getCh` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `getCh`(
nameCh MEDIUMTEXT,
username_in MEDIUMTEXT
)
BEGIN
	SELECT
		us.username,
        us.password,
        st.id
    FROM
		users us,xtream_iptvpro.streams st
	WHERE
		st.stream_display_name=nameCh && us.username=username_in;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getSettings` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `getSettings`()
BEGIN
	SELECT
    st.nameServer, 
    st.email, 
    st.logo, st.facebookpage, 
    st.xtreampage, 
    st.twitterpage
    FROM 
		nobrain_middleware.settings st;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getTrialActiveCode` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `getTrialActiveCode`(
ip_in mediumtext
)
BEGIN
	DECLARE checke INT DEFAULT 0;
    DECLARE acte INT;
    
    SELECT
		iac.id
	INTO
		checke
	FROM
		ipActiveCode iac
	WHERE
		iac.ip=ip_in;
    
    IF checke = 0 THEN
		SELECT
			aC.numberCode
		INTO
			acte
		FROM
			nobrain_middleware.activeCode aC
		INNER JOIN
			xtream_iptvpro.users us
				ON us.id=aC.idClient && us.created_by=208 && aC.active=0 && aC.duree='1 days'
		LIMIT 1;
		
        INSERT INTO
			ipActiveCode(activecode, ip)
        VALUE
			(acte,ip_in);
            
		SELECT acte;
	END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `updateAccount` */;
ALTER DATABASE `nobrain_middleware` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `updateAccount`(
gold_in INT,
silver_in INT,
bronze_in INT,
idregus_in INT,
idregusowner_in INT
)
BEGIN
	DECLARE GoldAct INT;
    DECLARE SilverAct INT;
    DECLARE BronzeAct INT;
    DECLARE OneDAct INT;
    
	SELECT
		rL.Months12,
        rL.Months6,
        rL.Months1,
        rL.Days1
	INTO
		GoldAct,SilverAct,BronzeAct,OneDAct
	FROM
		nobrain_middleware.revendeurLimit rL
	WHERE
		rL.idReg=idregusowner_in;
        
	IF (GoldAct>=gold_in) && (SilverAct>=silver_in) && (BronzeAct>=bronze_in) THEN
		UPDATE nobrain_middleware.revendeurLimit
		SET Months12=Months12+gold_in,Months6=Months6+silver_in,Months1=Months1+bronze_in,Days1=Days1+(ceil(gold_in/220)+ceil(silver_in/80)+ceil(bronze_in/20))
		WHERE idReg=idregus_in;
        
        UPDATE nobrain_middleware.revendeurLimit
		SET Months12=Months12-gold_in,Months6=Months6-silver_in,Months1=Months1-bronze_in
		WHERE idReg=idregusowner_in;
    END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `nobrain_middleware` CHARACTER SET utf8 COLLATE utf8_general_ci ;


--
-- Dumping routines for database 'xtream_iptvpro'
--
/*!50003 DROP FUNCTION IF EXISTS `getIDLINE` */;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET utf8 COLLATE utf8_unicode_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `getIDLINE`(
usernamus_in mediumtext
) RETURNS int(11)
BEGIN
	RETURN(
		SELECT
			us.id
		FROM
			users us
		WHERE
			us.username=usernamus_in
	);
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 DROP FUNCTION IF EXISTS `levelUser` */;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET utf8 COLLATE utf8_unicode_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `levelUser`(idreg_in double) RETURNS int(11)
BEGIN
    DECLARE lvl INT;
 
    SELECT
		ru.member_group_id
	INTO 
		lvl
	FROM
		reg_users ru
	WHERE
		ru.id=idreg_in;
        
 RETURN (lvl);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 DROP FUNCTION IF EXISTS `returnIDLINE` */;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `returnIDLINE`(
username_in mediumtext
) RETURNS int(11)
BEGIN
	RETURN(	SELECT
				us.id
			FROM
				users us
			WHERE
				us.username=username_in
	);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 DROP FUNCTION IF EXISTS `ReturnIDREG` */;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `ReturnIDREG`(usernameReg varchar(255)) RETURNS text CHARSET utf8
BEGIN
RETURN(
	SELECT
		id
	FROM
		reg_users
	WHERE 
		username=usernameReg);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 DROP FUNCTION IF EXISTS `returnNewName` */;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `returnNewName`(
oldnamech_in mediumtext
) RETURNS text CHARSET utf8
BEGIN
RETURN(
	SELECT
		ar.newname
	FROM
		nobrain_middleware.arabChannels ar
	WHERE
		ar.oldname=oldnamech_in
	);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `addAccount` */;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `addAccount`(
gold_in INT,
silver_in INT,
bronze_in INT,
idregus_in INT
)
BEGIN
	UPDATE nobrain_middleware.revendeurLimit
    SET Months12=Months12+gold_in,Months6=Months6+silver_in,Months1=Months1+bronze_in,Days1=Days1+(gold_in+silver_in+bronze_in)
    WHERE idReg=idregus_in;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `addCH` */;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET utf8 COLLATE utf8_unicode_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `addCH`(
nameCh_in varchar(255) ,
linkCh_in varchar(255)
)
BEGIN
    
	DECLARE stati INT;
	
    SELECT
		CASE
			WHEN sts.pid <> -1  THEN 1
            WHEN sts.pid = -1 OR sts.pid IS NULL THEN 0
        END as state
	INTO
		stati
	FROM
		streams_sys sts
	INNER JOIN
		streams st
			ON st.id=sts.stream_id && st.stream_display_name=nameCh_in;
            
	IF stati=0 THEN
    	SET SQL_SAFE_UPDATES = 0;
			UPDATE 
				xtream_iptvpro.streams
			SET 
				stream_source =CONCAT('[\"',linkCh_in,'"]')
			WHERE 
				stream_display_name collate utf8_general_ci = nameCh_in;
                
			UPDATE 
				xtream_iptvpro.streams_sys stse
			INNER JOIN
				xtream_iptvpro.streams st
					ON st.id=stse.stream_id
			SET 
				stse.to_analyze=1
			WHERE 
				st.stream_display_name collate utf8_general_ci =nameCh_in;
                
		
        SET SQL_SAFE_UPDATES = 1;
    END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `addEnigma` */;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `addEnigma`(
mac_in mediumtext,
userid_in INT
)
BEGIN
INSERT INTO 
	xtream_iptvpro.enigma2_devices(
		mac,
        user_id,
        modem_mac,
        local_ip,
        public_ip,
        key_auth,
        enigma_version,
        cpu,
        version,
        lversion,
        token,
        last_updated,
        watchdog_timeout,
        lock_device,
        telnet_enable,
        ftp_enable,
        ssh_enable
        )
VALUE
	(
		mac_in,
        userid_in,
        '',
        '',
        '',
        '',
        '',
        '',
        '',
        '',
        '',
        0,
        0,
        0,
        1,
        1,
        1
    );
    INSERT INTO
		nobrain_middleware.enigmaLine(idline)
	value
		(userid_in);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `addUsers` */;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET utf8 COLLATE utf8_unicode_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `addUsers`(
memberid_in INT,
username_in varchar(255),
bouquet_in varchar(255),
reguserid_in INT,
ismag_in INT,
ise2_in INT,
duree_in VARCHAR(255),
firstname_in varchar(255),
familyname_in varchar(255),
phonenumber_in varchar(255),
output_in INT,
duration_in varchar(255),
note_in mediumtext,
email_in varchar(255),
activecode_in varchar(255)
)
BEGIN

  
  IF ismag_in=0 AND ise2_in=0 THEN
	INSERT INTO users (
						`member_id`,
						`username`,
						`password`,
						`exp_date`,
                        `admin_enabled`,
                        `enabled`,
                        `admin_notes`,
                        `reseller_notes`,
                        `bouquet`,
                        `max_connections`,
						`is_restreamer`,
						`allowed_ips`,
						`allowed_ua`,
						`is_trial`,
						`created_at`,
						`created_by`,
						`pair_id`,
						`is_mag`,
                        `is_e2`,
						`force_server_id`,
						`is_isplock`,
						`isp_desc`,
						`forced_country`,
						`is_stalker`,
						`bypass_ua`
)
VALUES
  (
    memberid_in,
    username_in,
    LEFT (UUID(), 8),
    NULL,
    1,
    0,
    'Panel AR',
    note_in,
    bouquet_in,
    1,
    0,
    '[]',
    '[]',
    0,
    UNIX_TIMESTAMP(CURRENT_TIMESTAMP()),
    reguserid_in,
    NULL,
    ismag_in,
    ise2_in,
    0,
    0,
    '',
    '',
    0,
    0
  );
	
	INSERT INTO
		nobrain_middleware.activeCode(idClient,numberCode, username, duree, active)
	VALUE
		((SELECT MAX(id) FROM xtream_iptvpro.users) ,activecode_in,username_in,duree_in,0);
        
  END IF;
  
  IF ismag_in=1 THEN
	INSERT INTO users (
						`member_id`,
						`username`,
						`password`,
						`exp_date`,
                        `admin_enabled`,
                        `enabled`,
                        `admin_notes`,
                        `reseller_notes`,
                        `bouquet`,
                        `max_connections`,
						`is_restreamer`,
						`allowed_ips`,
						`allowed_ua`,
						`is_trial`,
						`created_at`,
						`created_by`,
						`pair_id`,
						`is_mag`,
						`force_server_id`,
						`is_isplock`,
						`isp_desc`,
						`forced_country`,
						`is_stalker`,
						`bypass_ua`
)
VALUES
  (
    memberid_in,
    username_in,
    LEFT (UUID(), 8),
    unix_timestamp(duree_in),
    1,
    1,
    '',
    note_in,
    bouquet_in,
    1,
    0,
    '[]',
    '[]',
    0,
    UNIX_TIMESTAMP(CURRENT_TIMESTAMP()),
    reguserid_in,
    NULL,
    ismag_in,
    0,
    0,
    '',
    '',
    0,
    0
  );
	INSERT INTO
		nobrain_middleware.activeCode(idClient,numberCode, username, duree, active)
	VALUE
		((SELECT MAX(id) FROM xtream_iptvpro.users) ,activecode_in,username_in,duree_in,1);
  END IF;
  
  IF ise2_in=1 THEN
	INSERT INTO users (
						`member_id`,
						`username`,
						`password`,
						`exp_date`,
                        `admin_enabled`,
                        `enabled`,
                        `admin_notes`,
                        `reseller_notes`,
                        `bouquet`,
                        `max_connections`,
						`is_restreamer`,
						`allowed_ips`,
						`allowed_ua`,
						`is_trial`,
						`created_at`,
						`created_by`,
						`pair_id`,
						`is_mag`,
                        `is_e2`,
						`force_server_id`,
						`is_isplock`,
						`isp_desc`,
						`forced_country`,
						`is_stalker`,
						`bypass_ua`
)
VALUES
  (
    memberid_in,
    username_in,
    LEFT (UUID(), 8),
    unix_timestamp(duree_in),
    1,
    1,
    'Panel AR',
    note_in,
    bouquet_in,
    1,
    0,
    '[]',
    '[]',
    0,
    UNIX_TIMESTAMP(CURRENT_TIMESTAMP()),
    reguserid_in,
    NULL,
    0,
    0,
    0,
    0,
    '',
    '',
    0,
    0
  );
	INSERT INTO
		nobrain_middleware.activeCode(idClient,numberCode, username, duree, active)
	VALUE
		((SELECT us.id FROM xtream_iptvpro.users us WHERE us.username=username_in) ,activecode_in,username_in,duree_in,1);
  END IF;
  
	INSERT INTO 
		nobrain_middleware.infolines(idlines, firstname, familyname, phone,email)
	VALUES
		((SELECT us.id FROM xtream_iptvpro.users us WHERE us.username=username_in),firstname_in,familyname_in,phonenumber_in,email_in);
	
    
	INSERT INTO 
		user_output(user_id, access_output_id) 
    VALUES
		((SELECT us.id FROM xtream_iptvpro.users us WHERE us.username=username_in),output_in);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `analyseOFFCh` */;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `analyseOFFCh`()
BEGIN
	UPDATE 
		xtream_iptvpro.streams_sys sts
	INNER JOIN
		streams st
		ON st.id=sts.stream_id && st.category_id is not null
	SET
		sts.to_analyze=1
	WHERE
		sts.pid = -1 && sts.progress_info <> '[]';
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `changeActiveCode` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `changeActiveCode`(
idus_in INT,
idreg_in INT,
membergr_in INT,
activecode_in MEDIUMTEXT
)
BEGIN
	IF membergr_in=5 THEN
		UPDATE
			nobrain_middleware.activeCode act
		INNER JOIN
			xtream_iptvpro.users us
            ON us.id=act.idClient
		SET
			act.numberCode=activecode_in
		WHERE
			act.idClient=idus_in && us.created_by=idreg_in;
            
		UPDATE
			xtream_iptvpro.users us
		SET
			us.username=activecode_in
		WHERE
			us.id=idus_in && us.created_by=idreg_in;
            
		UPDATE
			nobrain_middleware.infolines inf
		INNER JOIN
			xtream_iptvpro.users us
            ON us.id=inf.idlines
		SET
			inf.limitchangeact=inf.limitchangeact+1
		WHERE
			inf.idlines=idus_in && us.created_by=idreg_in;
    END IF;
    IF membergr_in=1 THEN
		UPDATE
			nobrain_middleware.activeCode act
		SET
			act.numberCode=activecode_in
		WHERE
			act.idClient=idus_in;
            
		UPDATE
			xtream_iptvpro.users us
		SET
			us.username=activecode_in
		WHERE
			us.id=idus_in;
    END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `changeSrc` */;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `changeSrc`(
namech_in mediumtext,
link_in mediumtext
)
BEGIN
	DECLARE stati INT;

	SET SQL_SAFE_UPDATES=0;
    SET collation_connection = 'utf8_general_ci';

		UPDATE
			xtream_iptvpro.streams st
		SET
			st.stream_source=CONCAT('[\"',link_in,'"]')
		WHERE
			st.stream_display_name=returnNewName(namech_in);


	
    SELECT
		CASE
			WHEN sts.pid <> -1  THEN 1
            WHEN sts.pid = -1 OR sts.pid IS NULL THEN 0
        END as state
	INTO
		stati
	FROM
		streams_sys sts
	INNER JOIN
		streams st
			ON st.id=sts.stream_id && st.stream_display_name=returnNewName(namech_in);

            
	IF stati=0 THEN
			UPDATE 
				xtream_iptvpro.streams_sys stse
			INNER JOIN
				xtream_iptvpro.streams st
					ON st.id=stse.stream_id
			SET 
				stse.to_analyze=1
			WHERE 
				st.stream_display_name=returnNewName(namech_in);

	END IF;
			
			
	SET SQL_SAFE_UPDATES=1;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `changeStateLine` */;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `changeStateLine`(
idus_in INT,
idreg_in INT,
membergr_in INT
)
BEGIN
	DECLARE enbl INT DEFAULT 0;
    DECLARE activestate INT DEFAULT 0;
    
	IF membergr_in=5 THEN

    
    SELECT
		act.active
	INTO
		activestate
	FROM
		nobrain_middleware.activeCode act
	INNER JOIN
		users us
	ON
		us.id=act.idClient && us.created_by=idreg_in && act.idClient=idus_in;
    
    IF activestate = 1 THEN
    
		SELECT 
			us.enabled
		INTO
			enbl
		FROM
			users us
		WHERE
			us.created_by=idreg_in && us.id=idus_in;

		IF enbl = 0 THEN
			UPDATE users
			SET enabled=1
			WHERE id=idus_in;
		END IF;
    
    
		IF enbl = 1 THEN
			UPDATE users
			SET enabled=0
			WHERE id=idus_in;
		END IF;
    
		END IF;
    END IF;
    
    IF membergr_in = 1 THEN

    SELECT
		act.active
	INTO
		activestate
	FROM
		nobrain_middleware.activeCode act
	INNER JOIN
		users us
	ON
		us.id=act.idClient &&  act.idClient=idus_in;
    
    IF activestate = 1 THEN
    
		SELECT 
			us.enabled
		INTO
			enbl
		FROM
			users us
		WHERE
			us.id=idus_in;

		IF enbl = 0 THEN
			UPDATE users
			SET enabled=1
			WHERE id=idus_in;
		END IF;
    
    
		IF enbl = 1 THEN
			UPDATE users
			SET enabled=0
			WHERE id=idus_in;
		END IF;
    
		END IF;
    END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `checkLineGet` */;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET utf8 COLLATE utf8_unicode_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `checkLineGet`(
activecode_in varchar(255)
)
BEGIN

DECLARE iduser INT DEFAULT 0;
DECLARE dureeAbo DATETIME DEFAULT 0;
DECLARE stateEnabled INT DEFAULT 0;

SELECT
	acty.active
INTO
	stateEnabled
FROM
	nobrain_middleware.activeCode acty
WHERE
	acty.numberCode=activecode_in;
    
IF stateEnabled=0 THEN

SELECT
	uan.user_id
INTO
	iduser
FROM
	user_activity_now uan
INNER JOIN
	nobrain_middleware.activeCode aC
		ON aC.idClient=uan.user_id && aC.numberCode=activecode_in;

SELECT
	ua.user_id
INTO
	iduser
FROM
	user_activity ua
INNER JOIN
	nobrain_middleware.activeCode aC
		ON aC.idClient=ua.user_id && aC.numberCode=activecode_in;
        
IF iduser=0 THEN
	CASE
		WHEN ((SELECT aC.duree FROM nobrain_middleware.activeCode aC WHERE aC.numberCode=activecode_in) = '12 months') THEN SET dureeAbo=DATE_ADD(NOW(), INTERVAL 12 MONTH);
        WHEN ((SELECT aC.duree FROM nobrain_middleware.activeCode aC WHERE aC.numberCode=activecode_in) = '6 months') THEN SET dureeAbo=DATE_ADD(NOW(), INTERVAL 6 MONTH);
        WHEN ((SELECT aC.duree FROM nobrain_middleware.activeCode aC WHERE aC.numberCode=activecode_in) = '3 months') THEN SET dureeAbo=DATE_ADD(NOW(), INTERVAL 3 MONTH);
        WHEN ((SELECT aC.duree FROM nobrain_middleware.activeCode aC WHERE aC.numberCode=activecode_in) = '1 months') THEN SET dureeAbo=DATE_ADD(NOW(), INTERVAL 1 MONTH);
                WHEN ((SELECT aC.duree FROM nobrain_middleware.activeCode aC WHERE aC.numberCode=activecode_in) = '1 days') THEN SET dureeAbo=DATE_ADD(NOW(), INTERVAL 1 DAY);

    END CASE;
	
    SET SQL_SAFE_UPDATES=0;
    UPDATE
		users us4
	INNER JOIN
		nobrain_middleware.activeCode act4
			ON act4.idClient=us4.id && act4.numberCode=activecode_in
	SET
		us4.exp_date=unix_timestamp(dureeAbo),us4.enabled=1,act4.active=1;
	SET SQL_SAFE_UPDATES=1;
        
END IF;

END IF;

SELECT 
    us.username, 
    us.password, 
    FROM_UNIXTIME(us.exp_date),
    CASE
        WHEN uan.activity_id IS NOT NULL THEN 'ON'
        WHEN uan.activity_id IS NULL THEN 'OFF'
    END AS linestate,
    us.enabled
FROM
    users us
        INNER JOIN
    nobrain_middleware.activeCode TP ON TP.IdClient = us.id
        && TP.numberCode = activecode_in
         LEFT JOIN
    user_activity_now uan ON uan.user_id = us.id;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `convertToEnigma` */;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `convertToEnigma`(
idline_in INT,
idreg_in INT,
mac_in mediumtext
)
BEGIN
	DECLARE idn INT DEFAULT 0;
	SELECT
		us.id
	INTO
		idn
	FROM
		users us
	WHERE
		us.member_id=idreg_in && us.id=idline_in;
	
    IF idn <> 0 THEN
		UPDATE
			users us
		SET
			us.is_e2=1,
            us.is_mag=0
		WHERE
			us.id=idn;
            
		INSERT INTO 
			enigma2_devices
			(
				mac,
				user_id,
				modem_mac,
				local_ip,
				public_ip,
				key_auth,
				enigma_version,
				cpu,
				version,
				lversion,
				token,
				last_updated,
				watchdog_timeout,
				lock_device,
				telnet_enable,
				ftp_enable,
				ssh_enable
			)
		VALUES
			(
				mac_in,
				idn,
				'',
				'',
				'',
				'',
				'',
				'',
				'',
				'',
				'',
				0,
				0,
				0,
				1,
				1,
				1
			);
    END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `convertToMag` */;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `convertToMag`(
idline_in INT,
idreg_in INT,
mac_in mediumtext
)
BEGIN
	DECLARE idn INT DEFAULT 0;
	SELECT
		us.id
	INTO
		idn
	FROM
		users us
	WHERE
		us.member_id=idreg_in && us.id=idline_in;
	
    IF idn <> 0 THEN
		UPDATE
			users us
		SET
			us.is_mag=1,
            us.is_e2=0
		WHERE
			us.id=idn;
            
		INSERT INTO 
			mag_devices
				(`user_id`,
				`bright`,
				`contrast`,
				`saturation`,
				`aspect`,
				`video_out`,
				`volume`,
				`playback_buffer_bytes`,
				`playback_buffer_size`,
				`audio_out`,
				`mac`,
				`ip`,
				`ls`,
				`ver`,
				`lang`,
				`locale`,
				`city_id`,
				`hd`,
				`main_notify`,
				`fav_itv_on`,
				`now_playing_start`,
				`now_playing_type`,
				`now_playing_content`,
				`time_last_play_tv`,
				`time_last_play_video`,
				`hd_content`,
				`image_version`,
				`last_change_status`,
				`last_start`,
				`last_active`,
				`keep_alive`,
				`playback_limit`,
				`screensaver_delay`,
				`stb_type`,
				`sn`,
				`last_watchdog`,
				`created`,
				`country`,
				`plasma_saving`,
				`ts_enabled`,
				`ts_enable_icon`,
				`ts_path`,
				`ts_max_length`,
				`ts_buffer_use`,
				`ts_action_on_exit`,
				`ts_delay`,
				`video_clock`,
				`rtsp_type`,
				`rtsp_flags`,
				`stb_lang`,
				`display_menu_after_loading`,
				`record_max_length`,
				`plasma_saving_timeout`,
				`now_playing_link_id`,
				`now_playing_streamer_id`,
				`device_id`,
				`device_id2`,
				`hw_version`,
				`parent_password`,
				`spdif_mode`,
				`show_after_loading`,
				`play_in_preview_by_ok`,
				`hdmi_event_reaction`,
				`mag_player`,
				`play_in_preview_only_by_ok`,
				`fav_channels`,
				`tv_archive_continued`,
				`tv_channel_default_aspect`,
				`last_itv_id`,
				`units`,
				`token`,
				`lock_device`)
	VALUES
				(idn,
				200,
				127,
				127,
				'',
				'rca',
				50,
				0,
				0,
				1,
				mac_in,
				NULL,
				NULL,
				NULL,
				NULL,
				'en_GB.utf8',
				0,
				1,
				1,
				0,
				NULL,
				0,
				NULL,
				NULL,
				NULL,
				1,
				NULL,
				NULL,
				NULL,
				NULL,
				NULL,
				3,
				10,
				'',
				NULL,
				NULL,
				unix_timestamp(),
				NULL,
				0,
				0,
				1,
				NULL,
				3600,
				'cyclic',
				'no_save',
				'on_pause',
				'Off',
				4,
				0,
				'en',
				1,
				180,
				600,
				NULL,
				NULL,
				NULL,
				NULL,
				NULL,
				'0000',
				1,
				'main_menu',
				1,
				1,
				NULL,
				'true',
				'',
				'',
				'stretch',
				0,
				'metric',
				NULL,
				1);
    END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `createRegUsers` */;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET utf8 COLLATE utf8_unicode_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `createRegUsers`(
firstname_in mediumtext,
lastname_in mediumtext,
phone_in mediumtext,
username_in varchar(255),
password_in varchar(255),
email_in varchar(255),
ownedby_in INT
)
BEGIN
        DECLARE idreg_get INT DEFAULT 0;
        DECLARE listpa_get MEDIUMTEXT;

	INSERT INTO `xtream_iptvpro`.`reg_users`
	(
		`username`,
		`password`,
		`email`,
		`ip`,
		`date_registered`,
		`verify_key`,
		`last_login`,
		`member_group_id`,
		`verified`,
		`credits`,
		`notes`,
		`status`,
		`default_lang`,
		`reseller_dns`,
		`owner_id`,
		`override_packages`)
	VALUES
	(
		username_in,
		ENCRYPT(password_in,CONCAT('$6$','rounds=20000$','xtreamcodes$')),
		email_in,
		'',
		UNIX_TIMESTAMP(CURDATE()),
		NULL,
		NULL,
		5,
		1,
		0,
		NULL,
		1,
		'English',
		'',
		ownedby_in,
		NULL);
        
        SELECT
			re.id
		INTO
			idreg_get
		FROM
			reg_users re
		WHERE
			re.username=username_in;
            
		SELECT
			re.listPackage
		INTO
			listpa_get
		FROM
			nobrain_middleware.resellerOffer re
		WHERE
			re.idRev=ownedby_in;
        
        
		IF idreg_get <> 0 THEN
			INSERT INTO
				nobrain_middleware.inforeseller(idreg, fristname, familyname, phone)
			VALUES
				(idreg_get,firstname_in,lastname_in,phone_in);
                
			INSERT INTO
				nobrain_middleware.revendeurLimit(idReg, Months12, Months6, Months1,Days1,SD12, SD6, SD1,SDAYS1,EMonths12, EDAYS1)
			VALUES
				(idreg_get,0,0,0,0,0,0,0,0,0,0);
			
            INSERT INTO
				nobrain_middleware.resellerOffer(idRev, listPackage)
			VALUE
				(idreg_get,listpa_get);
        END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `createTicket` */;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `createTicket`(
member_id_in INT,
title_in varchar(255),
message_in varchar(255)
)
BEGIN
	DECLARE idticket INT DEFAULT 0;
	INSERT INTO
		xtream_iptvpro.tickets(member_id, title, status, admin_read, user_read)
	VALUES
		(member_id_in,title_in,1,0,1);
        
	SELECT
		ti.id
	INTO
		idticket
	FROM
		tickets ti
	WHERE
		ti.member_id=member_id_in && ti.title=title_in
	ORDER BY ti.id DESC
    LIMIT 1;
	
    IF idticket <> 0 THEN
		INSERT INTO
			xtream_iptvpro.tickets_replies(ticket_id, admin_reply, message, date)
		VALUES
			(idticket,0,message_in,unix_timestamp(now()));
	END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `deleteCreditsRes` */;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `deleteCreditsRes`(
	credit12_in INT,
    credit6_in INT,
    credit1_in INT,
    idRegUsers_in INT
)
BEGIN

DECLARE cr12 INT DEFAULT 220;
DECLARE cr6 INT DEFAULT 80;
DECLARE cr1 INT DEFAULT 20;

UPDATE
	nobrain_middleware.revendeurLimit
SET
	Months12=Months12-credit12_in,Months6=Months6-credit6_in,Months1=Months1-credit1_in
WHERE
	idReg=idRegUsers_in && credit12_in>=0 && credit6_in>=0 && credit1_in>=0;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `deleteFirstChar` */;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET utf8 COLLATE utf8_unicode_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `deleteFirstChar`(
prefix_in mediumtext
)
BEGIN
SET SQL_SAFE_UPDATES=0;
	IF prefix_in LIKE '% :%' THEN
		UPDATE 
			xtream_iptvpro.streams st
		SET
			stream_display_name=UPPER(SUBSTR(st.stream_display_name, 5))
		WHERE
			st.stream_display_name LIKE CONCAT(prefix_in, '%') COLLATE utf8_unicode_ci;
        
		UPDATE 
			xtream_iptvpro.streams st
		SET
			stream_display_name=UPPER(SUBSTR(st.stream_display_name, 2))
		WHERE
			st.stream_display_name LIKE ' %' COLLATE utf8_unicode_ci;
	END IF;
	IF prefix_in LIKE '%:%' THEN
		UPDATE 
			xtream_iptvpro.streams st
		SET
			stream_display_name=UPPER(SUBSTR(st.stream_display_name, 4))
		WHERE
			st.stream_display_name LIKE CONCAT(prefix_in, '%') COLLATE utf8_unicode_ci;
        
		UPDATE 
			xtream_iptvpro.streams st
		SET
			stream_display_name=UPPER(SUBSTR(st.stream_display_name, 2))
		WHERE
			st.stream_display_name LIKE ' %' COLLATE utf8_unicode_ci;
	END IF;
SET SQL_SAFE_UPDATES=1;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `deleteLine` */;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `deleteLine`(
idus_in INT,
idreg_in INT,
membergr_in INT
)
BEGIN
	DECLARE id INT DEFAULT 0;
    IF membergr_in=5 THEN
		SELECT 
			us.id
		INTO
			id
		FROM
			users us
		WHERE
			us.created_by=idreg_in && us.id=idus_in;
        
		IF id <> 0 THEN
			DELETE us FROM users us
			WHERE us.id=idus_in;
		END IF;
    END IF;
    IF membergr_in=1 THEN
		SELECT 
			us.id
		INTO
			id
		FROM
			users us
		WHERE
			us.id=idus_in;
        
		IF id <> 0 THEN
			DELETE us FROM users us
			WHERE us.id=idus_in;
		END IF;
    END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `deviceUsers` */;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `deviceUsers`(
idreg_int INT
)
BEGIN
SELECT
	ua.user_agent,
    round(COUNT(ua.user_agent)/(SELECT SUM(tb.nbr) FROM (SELECT COUNT(ua.user_agent) as nbr FROM xtream_iptvpro.user_activity ua INNER JOIN users us ON us.id=ua.user_id && us.created_by=idreg_int GROUP BY ua.user_agent) as tb)*100,2) as average
FROM 
	xtream_iptvpro.user_activity ua
INNER JOIN
	users us
		ON us.id=ua.user_id && us.created_by=idreg_int
GROUP BY 
	ua.user_agent
ORDER BY
	average DESC
LIMIT 3;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `disableReseller` */;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `disableReseller`(
idowner_in INT,
idreseller_in INT
)
BEGIN
	DECLARE stateRev INT;
    
    SELECT
		ru.status
	INTO
		stateRev
	FROM
		reg_users ru
	WHERE 
		ru.owner_id=idowner_in && ru.id=idreseller_in;
    
    IF stateRev=0 THEN
		UPDATE 
			reg_users
		SET
			status=1
		WHERE
			owner_id=idowner_in && id=idreseller_in;
    END IF;
    
    IF stateRev=1 THEN
		UPDATE 
			reg_users
		SET
			status=0
		WHERE
			owner_id=idowner_in && id=idreseller_in;
    END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `editReseller` */;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `editReseller`(
firstname_in mediumtext,
lastname_in mediumtext,
phone_in mediumtext,
email_in mediumtext,
password_in mediumtext,
idreseller_in INT,
ownerid_in INT
)
BEGIN
	DECLARE curPw mediumtext;
	SELECT
		rue.password
	INTO
		curPw
	FROM
		xtream_iptvpro.reg_users rue
	WHERE
		rue.id=idreseller_in && rue.owner_id=ownerid_in;
        
	IF password_in='' THEN
	UPDATE
		nobrain_middleware.inforeseller infr
	INNER JOIN
		xtream_iptvpro.reg_users ru
			ON ru.id=infr.idreg
	SET
		infr.fristname=firstname_in,infr.familyname=lastname_in,infr.phone=phone_in,ru.email=email_in,ru.password=curPw
	WHERE
		ru.id=idreseller_in && ru.owner_id=ownerid_in;
        ELSE
			IF password_in <> '' THEN
				UPDATE
					nobrain_middleware.inforeseller infr
				INNER JOIN
					xtream_iptvpro.reg_users ru
						ON ru.id=infr.idreg
							SET
								infr.fristname=firstname_in,infr.familyname=lastname_in,infr.phone=phone_in,ru.email=email_in,ru.password=ENCRYPT(password_in,CONCAT('$6$','rounds=20000$','xtreamcodes$'))
				WHERE
					ru.id=idreseller_in && ru.owner_id=ownerid_in;
            END IF;
	END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `EngimaToLine` */;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `EngimaToLine`(
idreg_in INT,
idenigma_in INT
)
BEGIN
	DECLARE idn INT DEFAULT 0;
	SELECT
		us.id
	INTO
		idn
	FROM
		users us
	INNER JOIN
		enigma2_devices en
			ON en.user_id=us.id && en.device_id=idenigma_in
	WHERE
		us.member_id=idreg_in;
        
    IF idn <> 0 THEN
		DELETE eg FROM
			nobrain_middleware.enigmaLine eg
		WHERE
			eg.idline=idn;
            
		DELETE en FROM
			enigma2_devices en
		WHERE
			en.device_id=idenigma_in && en.user_id=idn;
    END IF;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `fixExtention` */;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `fixExtention`()
BEGIN
UPDATE
	streams st
SET
	st.target_container='mkv'
WHERE
	st.type=2 && st.stream_source LIKE '%.mkv"]';
    
UPDATE
	streams st
SET
	st.target_container='avi'
WHERE
	st.type=2 && st.stream_source LIKE '%.avi"]';
    
UPDATE
	streams st
SET
	st.target_container='mp4'
WHERE
	st.type=2 && st.stream_source LIKE '%.mp4"]';
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `flushIP` */;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `flushIP`()
BEGIN
	TRUNCATE nobrain_middleware.ipActiveCode;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `getActiveCode` */;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `getActiveCode`(
username_in VARCHAR(255)
)
BEGIN
	SELECT
		act.numberCode
    FROM
		nobrain_middleware.activeCode act
	INNER JOIN
		xtream_iptvpro.users us
        ON us.id=act.idClient && us.username=username_in;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `getAllDevice` */;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `getAllDevice`()
BEGIN
	SELECT 
		device_name,
		device_key 
    FROM 
		xtream_iptvpro.devices;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `getAllEnigma` */;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `getAllEnigma`(
ruid_int INT,
membergr_in INT
)
BEGIN
	IF membergr_in = 5 THEN
		SELECT
	 CASE
        WHEN uan.activity_id IS NOT NULL THEN 'ON'
        WHEN uan.activity_id IS NULL THEN 'OFF'
    END AS linestate,
    CASE
        WHEN us.enabled = 0 THEN 'DISABLED'
        WHEN us.enabled = 1 THEN 'ENABLED'
    END AS state,
	infL.firstname,
	infL.familyname,
    ma.mac,
    upper(ma.cpu),
    COALESCE(FROM_UNIXTIME(us.exp_date),'UNLIMITED') AS ExpDate,
	uan.user_ip AS IP,
     (SELECT 
            st.stream_display_name
        FROM
            user_activity_now uan
                INNER JOIN
            streams st ON st.id = uan.stream_id
        WHERE
            uan.user_id = us.id
        ORDER BY date_start DESC
        LIMIT 1) AS channelName,
        uan.geoip_country_code,
        (SELECT 
            st.stream_icon
        FROM
            user_activity_now uan
                INNER JOIN
            streams st ON st.id = uan.stream_id
        WHERE
            uan.user_id = us.id
        ORDER BY date_start DESC
        LIMIT 1) AS channelIcons,
        us.id,
        aC.numberCode,
		COALESCE(infL.email,''),
		COALESCE(us.reseller_notes,''),
        ma.device_id
FROM
	enigma2_devices ma
INNER JOIN
	users us
		ON us.id=ma.user_id
INNER JOIN
	nobrain_middleware.enigmaLine eg
    ON eg.idline=us.id
INNER JOIN
	nobrain_middleware.activeCode aC
		On aC.idClient=us.id
LEFT JOIN
    user_activity_now uan ON uan.user_id = us.id
INNER JOIN
	reg_users ru
		ON ru.id = us.member_id && ru.id = ruid_int
LEFT JOIN
	nobrain_middleware.infolines infL
		ON infL.idlines=us.id
GROUP BY us.id
ORDER BY channelIcons DESC;
END IF;


IF membergr_in = 1 THEN
		SELECT
	 CASE
        WHEN uan.activity_id IS NOT NULL THEN 'ON'
        WHEN uan.activity_id IS NULL THEN 'OFF'
    END AS linestate,
    CASE
        WHEN us.enabled = 0 THEN 'DISABLED'
        WHEN us.enabled = 1 THEN 'ENABLED'
    END AS state,
	infL.firstname,
	infL.familyname,
    ma.mac,
    UPPER(ma.cpu),
    COALESCE(FROM_UNIXTIME(us.exp_date),'UNLIMITED') AS ExpDate,
	uan.user_ip AS IP,
     (SELECT 
            st.stream_display_name
        FROM
            user_activity_now uan
                INNER JOIN
            streams st ON st.id = uan.stream_id
        WHERE
            uan.user_id = us.id
        ORDER BY date_start DESC
        LIMIT 1) AS channelName,
        uan.geoip_country_code,
        (SELECT 
            st.stream_icon
        FROM
            user_activity_now uan
                INNER JOIN
            streams st ON st.id = uan.stream_id
        WHERE
            uan.user_id = us.id
        ORDER BY date_start DESC
        LIMIT 1) AS channelIcons,
        us.id,
		aC.numberCode,
		COALESCE(infL.email,''),
		COALESCE(us.reseller_notes,''),
        ma.device_id,
		(SELECT ru.username FROM reg_users ru WHERE ru.id=us.created_by)
FROM
	enigma2_devices ma
INNER JOIN
	users us
		ON us.id=ma.user_id
INNER JOIN
	nobrain_middleware.enigmaLine eg
    ON eg.idline=us.id
INNER JOIN
	nobrain_middleware.activeCode aC
		On aC.idClient=us.id
LEFT JOIN
    user_activity_now uan ON uan.user_id = us.id
INNER JOIN
	reg_users ru
		ON ru.id = us.member_id
LEFT JOIN
	nobrain_middleware.infolines infL
		ON infL.idlines=us.id
GROUP BY us.id
ORDER BY channelIcons DESC;
END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `getAllInactiveLine` */;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `getAllInactiveLine`(
ruid_int INT
)
BEGIN
		SELECT
     case
	WHEN uan.activity_id IS NOT NULL THEN 'ON'
    WHEN uan.activity_id IS NULL THEN 'OFF'
  end AS linestate,
  case
	WHEN us.enabled=0 THEN 'DISABLED'
    WHEN us.enabled=1 THEN 'ENABLED'
  end AS state,
  infL.firstname,
  infL.familyname,
  infL.phone,
 act.numberCode AS ActiveCode,
  upper(act.duree),
  us.id
FROM
  users us
LEFT JOIN user_activity_now uan ON uan.user_id=us.id
INNER JOIN reg_users ru ON  ru.id = ruid_int && us.is_mag=0 && ru.id=us.created_by
LEFT JOIN nobrain_middleware.activeCode act
	ON act.idClient=us.id
LEFT JOIN
	nobrain_middleware.infolines infL
		ON infL.idlines=act.idClient
WHERE  act.active=0 && us.is_mag=0
GROUP BY us.id
ORDER BY us.created_at DESC;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `getAllLine` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `getAllLine`(
ruid_int INT,
membergroup_in INT
)
BEGIN
	IF membergroup_in=5 THEN
		SELECT
     case
	WHEN uan.activity_id IS NOT NULL THEN 'ON'
    WHEN uan.activity_id IS NULL THEN 'OFF'
  end AS linestate,
  case
	WHEN us.enabled=0 THEN 'DISABLED'
    WHEN us.enabled=1 THEN 'ENABLED'
  end AS state,
  infL.firstname,
  infL.familyname,
  FROM_UNIXTIME(us.created_at) AS CreatedAT,
  COALESCE(FROM_UNIXTIME(us.exp_date),'UNLIMITED') AS ExpDate,
 act.numberCode AS ActiveCode,
  uan.user_ip,
  (SELECT st.stream_display_name FROM user_activity_now uan INNER JOIN  streams st ON st.id=uan.stream_id WHERE uan.user_id=us.id ORDER BY date_start DESC LIMIT 1) as channelName,
    uan.geoip_country_code,
  (SELECT st.stream_icon FROM user_activity_now uan INNER JOIN  streams st ON st.id=uan.stream_id WHERE uan.user_id=us.id ORDER BY date_start DESC LIMIT 1) as channelIcon,
  us.id,
  infL.email,
  us.reseller_notes,
  (SELECT ru.username FROM reg_users ru WHERE ru.id=us.created_by),
  infL.limitchangeact,
  infL.limitpauseact
FROM
  users us
LEFT JOIN user_activity_now uan ON uan.user_id=us.id
INNER JOIN reg_users ru ON ru.id = ruid_int && us.is_mag=0 && us.is_e2=0 && ru.id=us.created_by
INNER JOIN nobrain_middleware.enigmaLine eg ON eg.idline <> us.id
LEFT JOIN nobrain_middleware.activeCode act
	ON act.idClient=us.id
LEFT JOIN
	nobrain_middleware.infolines infL
		ON infL.idlines=act.idClient
WHERE  act.active=1
GROUP BY us.id
ORDER BY channelIcon DESC;
END IF;

IF membergroup_in=1 THEN
		SELECT
     case
	WHEN uan.activity_id IS NOT NULL THEN 'ON'
    WHEN uan.activity_id IS NULL THEN 'OFF'
  end AS linestate,
  case
	WHEN us.enabled=0 THEN 'DISABLED'
    WHEN us.enabled=1 THEN 'ENABLED'
  end AS state,
  infL.firstname,
  infL.familyname,
  FROM_UNIXTIME(us.created_at) AS CreatedAT,
  COALESCE(FROM_UNIXTIME(us.exp_date),'UNLIMITED') AS ExpDate,
 act.numberCode AS ActiveCode,
  uan.user_ip,
  (SELECT st.stream_display_name FROM user_activity_now uan INNER JOIN  streams st ON st.id=uan.stream_id WHERE uan.user_id=us.id ORDER BY date_start DESC LIMIT 1) as channelName,
    uan.geoip_country_code,
  (SELECT st.stream_icon FROM user_activity_now uan INNER JOIN  streams st ON st.id=uan.stream_id WHERE uan.user_id=us.id ORDER BY date_start DESC LIMIT 1) as channelIcon,
  us.id,
  infL.email,
  us.reseller_notes,
  (SELECT ru.username FROM reg_users ru WHERE ru.id=us.created_by),
  infL.limitchangeact,
  infL.limitpauseact
FROM
  users us
LEFT JOIN user_activity_now uan ON uan.user_id=us.id
INNER JOIN reg_users ru ON ru.id = ruid_int && us.is_mag=0 && us.is_e2=0
INNER JOIN nobrain_middleware.enigmaLine eg ON eg.idline <> us.id
LEFT JOIN nobrain_middleware.activeCode act
	ON act.idClient=us.id
LEFT JOIN
	nobrain_middleware.infolines infL
		ON infL.idlines=act.idClient
WHERE  act.active=1
GROUP BY us.id
ORDER BY channelIcon DESC;
END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getAllMag` */;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET utf8 COLLATE utf8_unicode_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `getAllMag`(
ruid_int INT,
membergr_in INT
)
BEGIN
	IF membergr_in = 5 THEN
		SELECT
	 CASE
        WHEN uan.activity_id IS NOT NULL THEN 'ON'
        WHEN uan.activity_id IS NULL THEN 'OFF'
    END AS linestate,
    CASE
        WHEN us.enabled = 0 THEN 'DISABLED'
        WHEN us.enabled = 1 THEN 'ENABLED'
    END AS state,
	infL.firstname,
	infL.familyname,
    ma.mac,
    ma.stb_type,
    COALESCE(FROM_UNIXTIME(us.exp_date),'UNLIMITED') AS ExpDate,
	uan.user_ip AS IP,
     (SELECT 
            st.stream_display_name
        FROM
            user_activity_now uan
                INNER JOIN
            streams st ON st.id = uan.stream_id
        WHERE
            uan.user_id = us.id
        ORDER BY date_start DESC
        LIMIT 1) AS channelName,
        uan.geoip_country_code,
        (SELECT 
            st.stream_icon
        FROM
            user_activity_now uan
                INNER JOIN
            streams st ON st.id = uan.stream_id
        WHERE
            uan.user_id = us.id
        ORDER BY date_start DESC
        LIMIT 1) AS channelIcons,
        us.id,
        aC.numberCode,
        COALESCE(infL.email,''),
		COALESCE(us.reseller_notes,''),
        ma.mag_id,
        FROM_UNIXTIME(us.created_at) AS CreatedAT
FROM
	mag_devices ma
INNER JOIN
	users us
		ON us.id=ma.user_id
LEFT JOIN
    user_activity_now uan ON uan.user_id = us.id
INNER JOIN
	reg_users ru
		ON ru.id = us.member_id && ru.id = ruid_int && us.is_mag=1
INNER JOIN
	nobrain_middleware.activeCode aC
		On aC.idClient=us.id
LEFT JOIN
	nobrain_middleware.infolines infL
		ON infL.idlines=us.id
GROUP BY us.id
ORDER BY channelIcons DESC;
END IF;


IF membergr_in = 1 THEN
		SELECT
	 CASE
        WHEN uan.activity_id IS NOT NULL THEN 'ON'
        WHEN uan.activity_id IS NULL THEN 'OFF'
    END AS linestate,
    CASE
        WHEN us.enabled = 0 THEN 'DISABLED'
        WHEN us.enabled = 1 THEN 'ENABLED'
    END AS state,
	infL.firstname,
	infL.familyname,
    ma.mac,
    ma.stb_type,
    COALESCE(FROM_UNIXTIME(us.exp_date),'UNLIMITED') AS ExpDate,
	uan.user_ip AS IP,
     (SELECT 
            st.stream_display_name
        FROM
            user_activity_now uan
                INNER JOIN
            streams st ON st.id = uan.stream_id
        WHERE
            uan.user_id = us.id
        ORDER BY date_start DESC
        LIMIT 1) AS channelName,
        uan.geoip_country_code,
        (SELECT 
            st.stream_icon
        FROM
            user_activity_now uan
                INNER JOIN
            streams st ON st.id = uan.stream_id
        WHERE
            uan.user_id = us.id
        ORDER BY date_start DESC
        LIMIT 1) AS channelIcons,
        us.id,
        aC.numberCode,
        COALESCE(infL.email,''),
		COALESCE(us.reseller_notes,''),
        ma.mag_id,
		(SELECT ru.username FROM reg_users ru WHERE ru.id=us.created_by),
        FROM_UNIXTIME(us.created_at) AS CreatedAT
FROM
	mag_devices ma
INNER JOIN
	users us
		ON us.id=ma.user_id
INNER JOIN
	nobrain_middleware.activeCode aC
		On aC.idClient=us.id
LEFT JOIN
    user_activity_now uan ON uan.user_id = us.id
INNER JOIN
	reg_users ru
		ON ru.id = us.member_id  && us.is_mag=1
LEFT JOIN
	nobrain_middleware.infolines infL
		ON infL.idlines=us.id
GROUP BY us.id
ORDER BY channelIcons DESC;
END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `getAllNews` */;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `getAllNews`()
BEGIN
	SELECT
		nw.id,
        nw.news,
        from_unixtime(nw.dateAjout)
	FROM
		nobrain_middleware.NEWS nw
	ORDER BY
		from_unixtime(nw.dateAjout) DESC;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `getBouquetUser` */;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `getBouquetUser`(
activecode_in MEDIUMTEXT
)
BEGIN
	SELECT
		us.bouquet
    FROM
		users us
	INNER JOIN
		nobrain_middleware.activeCode aC
        ON aC.idClient=us.id && aC.numberCode=activecode_in;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `getCh` */;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `getCh`(
nameCh MEDIUMTEXT,
username_in MEDIUMTEXT
)
BEGIN
	SELECT
		us.username,
        us.password,
        st.id
    FROM
		users us,xtream_iptvpro.streams st
	WHERE
		st.stream_display_name=nameCh && us.username=username_in;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `getChanelName` */;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `getChanelName`()
BEGIN
		SELECT 
		st.stream_icon,
        st.stream_display_name as nomChaine,
		 CASE
			WHEN sts.pid <> -1  THEN 'ON'
            WHEN sts.pid = -1 OR sts.pid IS NULL THEN 'OFF'
        END as state,
        CASE
			WHEN progress_info <> '' THEN sts.bitrate
            WHEN progress_info = '' THEN '-'
        END as state
        
    FROM 
		xtream_iptvpro.streams st
	INNER JOIN
		xtream_iptvpro.streams_sys sts
			ON sts.stream_id=st.id
    WHERE 
		st.category_id IS NOT NULL && st.type=1
    ORDER BY 
		nomChaine ASC;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `getChannelUser` */;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `getChannelUser`(
idbq_in INT
)
BEGIN
	SELECT
        bq.bouquet_channels
    FROM
		bouquets bq
	WHERE
		bq.id=idbq_in;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `getCountUsers` */;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `getCountUsers`(
idreg_in INT,
dureeac_in MEDIUMTEXT,
typeac_in MEDIUMTEXT
)
BEGIN
	IF typeac_in='FULL HD' THEN
		SELECT
			COUNT(us.id)
		FROM
			users us
		INNER JOIN
			nobrain_middleware.activeCode aC
			ON aC.idClient=us.id && aC.duree=dureeac_in
		INNER JOIN
			packages pa
            ON pa.bouquets=us.bouquet && pa.bouquets=us.bouquet 
		WHERE
			us.created_by=idreg_in && us.enabled=0 && pa.id=8;
	END IF;
    IF typeac_in='HD' THEN
		SELECT
			COUNT(us.id)
		FROM
			users us
		INNER JOIN
			nobrain_middleware.activeCode aC
			ON aC.idClient=us.id && aC.duree=dureeac_in
		INNER JOIN
			packages pa
            ON pa.bouquets=us.bouquet && pa.bouquets=us.bouquet 
		WHERE
			us.created_by=idreg_in && us.enabled=0 && pa.id=12;
	END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `getDetailChannelUser` */;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailChannelUser`(
idch_in INT
)
BEGIN
	SELECT
        st.stream_display_name,
        sts.current_source
    FROM
		streams st
	INNER JOIN
		streams_sys sts
        ON sts.stream_id=st.id
	WHERE
		st.id=idch_in && sts.current_source IS NOT NULL;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `getEnigmaById` */;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET utf8 COLLATE utf8_unicode_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `getEnigmaById`(
idLine_in INT,
idReg_in INT,
memberGroup_in INT
)
BEGIN
	IF memberGroup_in=5 THEN
		SELECT 
			md.device_id,
			UPPER(md.cpu),
			md.mac,
			CASE
				WHEN us.exp_date is null THEN 'UNLIMITED'
				WHEN us.exp_date is not null THEN from_unixtime(us.exp_date)
			END as DateExpire,
			infL.firstname,
			infL.familyname,
			infL.phone,
			infL.email,
			us.reseller_notes
		FROM
			users us
		LEFT JOIN
			enigma2_devices md
				ON md.user_id=us.id
		LEFT JOIN
			nobrain_middleware.infolines infL
				ON infL.idlines=us.id
		WHERE
			us.created_by=idReg_in && us.id=idLine_in;
	ELSE
		IF memberGroup_in=1 THEN
			SELECT 
				md.device_id,
				UPPER(md.cpu),
				md.mac,
				CASE
					WHEN us.exp_date is null THEN 'UNLIMITED'
					WHEN us.exp_date is not null THEN from_unixtime(us.exp_date)
				END as DateExpire,
				infL.firstname,
				infL.familyname,
				infL.phone,
				infL.email,
				us.reseller_notes
			FROM
				users us
			LEFT JOIN
				enigma2_devices md
					ON md.user_id=us.id
			LEFT JOIN
				nobrain_middleware.infolines infL
					ON infL.idlines=us.id
			WHERE
				us.id=idLine_in;
        END IF;
	
	END IF;
        
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `getInfoPackage` */;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `getInfoPackage`(
idpackage_in INT
)
BEGIN
	SELECT 
		pa.id,
		pa.package_name,
		pa.bouquets,
        pa.official_credits,
        pa.official_duration, 
        pa.official_duration_in,
        pa.output_formats 
	FROM 
		packages pa 
    WHERE 
		pa.id=idpackage_in;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `getInfoReg` */;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET utf8 COLLATE utf8_unicode_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `getInfoReg`(
idreg_in INT
)
BEGIN
SELECT 
	re.*,
    rl.Months12,
    rl.Months6,
    rl.Months1,
    rl.Days1,
    rl.SD12,
    rl.SD6,
    rl.SD1,
    rl.SDAYS1,
    rl.EMonths12,
    rl.EDAYS1,
    rl.Months3,
    rl.SMonths3
FROM 
	reg_users re
INNER JOIN
	nobrain_middleware.revendeurLimit rl
		ON rl.idReg=re.id && re.id=idreg_in;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `getinstableChannel` */;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET utf8 COLLATE utf8_unicode_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `getinstableChannel`()
BEGIN
	SELECT
		CASE
			WHEN sts.pid <> -1 AND sts.bitrate >= 400 THEN 'ON'
            WHEN (sts.pid = -1 OR sts.pid IS NULL) OR (sts.bitrate <=400) THEN 'OFF'
        END as state,
		st.stream_display_name,
		stc.category_name,
        FROM_UNIXTIME((sTV.dateON)),
        FROM_UNIXTIME((sTV.dateOFF)),
         CASE
			WHEN sts.pid <> -1 AND sts.bitrate >= 400  THEN 0
            WHEN (sts.pid = -1  OR sts.pid IS NULL) OR (sts.bitrate <=400) THEN TIMEDIFF(TIME(now()),TIME(from_unixtime(sTV.dateOFF)))
        END as durationOFF,
        CASE
			WHEN sts.pid <> -1 AND sts.bitrate >= 400  THEN TIMEDIFF(TIME(from_unixtime(unix_timestamp())),TIME(from_unixtime(sTV.dateOFF)))
            WHEN (sts.pid = -1  OR sts.pid IS NULL) OR (sts.bitrate <=400) THEN 0
        END as durationON,
		sTV.numberupdate as nbON,
        COALESCE(COALESCE((SELECT COUNT(uan.stream_id) FROM xtream_iptvpro.user_activity uan WHERE uan.stream_id=sTV.id_str && DATE(from_unixtime(uan.date_start))=CURDATE() GROUP BY uan.stream_id),0)+COALESCE((SELECT COUNT(uan.stream_id) FROM xtream_iptvpro.user_activity_now uan WHERE uan.stream_id=sTV.id_str && DATE(from_unixtime(uan.date_start))=CURDATE() GROUP BY uan.stream_id),0),0),
        sts.current_source
	FROM 
		nobrain_middleware.stableTV sTV
	INNER JOIN
		xtream_iptvpro.streams st
			ON st.id=sTV.id_str
	INNER JOIN
		xtream_iptvpro.stream_categories stc
			ON stc.id=st.category_id
	INNER JOIN
		xtream_iptvpro.streams_sys sts
			ON sts.stream_id=st.id
	INNER JOIN
		xtream_iptvpro.streaming_servers stv
			ON stv.id=sts.server_id
	WHERE
		sTV.numberupdate >= 1 && DATE(from_unixtime(sTV.dateON))=DATE(now()) && DATE(from_unixtime(sTV.dateOFF))=DATE(now()) && TIMEDIFF(TIME(from_unixtime(unix_timestamp())),TIME(from_unixtime(sTV.dateOFF)))<TIME('01:00:00') AND sts.on_demand=0
	ORDER BY
		durationOFF DESC,nbON DESC;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `getLineById` */;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `getLineById`(
idLine_in INT,
idReg_in INT,
memberGroup_in INT
)
BEGIN
	IF memberGroup_in=5 THEN
	SELECT 
		us.id,
        inf.firstname,
        inf.familyname,
        ta.numberCode,
        CASE
			WHEN us.exp_date is null THEN 'UNLIMITED'
            WHEN us.exp_date is not null THEN from_unixtime(us.exp_date)
        END as DateExpire,
        inf.phone,
        inf.email,
        us.reseller_notes
    FROM
		users us
	LEFT JOIN
		nobrain_middleware.activeCode ta
			ON ta.idClient=us.id
	INNER JOIN
		nobrain_middleware.infolines inf
			ON inf.idlines=us.id
	WHERE
		us.created_by=idReg_in && us.id=idLine_in;
	END IF;
    IF memberGroup_in=1 THEN
	SELECT 
		us.id,
        inf.firstname,
        inf.familyname,
        ta.numberCode,
        CASE
			WHEN us.exp_date is null THEN 'UNLIMITED'
            WHEN us.exp_date is not null THEN from_unixtime(us.exp_date)
        END as DateExpire,
        inf.phone,
        inf.email,
        us.reseller_notes
    FROM
		users us
	LEFT JOIN
		nobrain_middleware.activeCode ta
			ON ta.idClient=us.id
	INNER JOIN
		nobrain_middleware.infolines inf
			ON inf.idlines=us.id
	WHERE
		us.id=idLine_in;
	END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `getLineRegID` */;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET utf8 COLLATE utf8_unicode_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `getLineRegID`(
ruid_int INT,
membergroup_in INT
)
BEGIN
	IF membergroup_in=1 THEN
		SELECT
     case
	WHEN uan.activity_id IS NOT NULL THEN 'ON'
    WHEN uan.activity_id IS NULL THEN 'OFF'
  end AS linestate,
  case
	WHEN us.enabled=0 THEN 'DISABLED'
    WHEN us.enabled=1 THEN 'ENABLED'
  end AS state,
  infL.firstname,
  infL.familyname,
  FROM_UNIXTIME(us.created_at) AS CreatedAT,
  CASE 
		WHEN us.exp_date IS NULL THEN 'NOT ACTIVATE'
		WHEN us.exp_date IS NOT NULL THEN COALESCE(FROM_UNIXTIME(us.exp_date),'UNLIMITED')
	END as ExpDate,
 act.numberCode AS ActiveCode,
  uan.user_ip,
  (SELECT st.stream_display_name FROM user_activity_now uan INNER JOIN  streams st ON st.id=uan.stream_id WHERE uan.user_id=us.id ORDER BY date_start DESC LIMIT 1) as channelName,
    uan.geoip_country_code,
  (SELECT st.stream_icon FROM user_activity_now uan INNER JOIN  streams st ON st.id=uan.stream_id WHERE uan.user_id=us.id ORDER BY date_start DESC LIMIT 1) as channelIcon,
  us.id,
  infL.email,
  us.reseller_notes,
	CASE 
		WHEN us.bouquet=(SELECT pa.bouquets FROM packages pa WHERE pa.id=8) THEN 'FULL HD'
		WHEN us.bouquet=(SELECT pa.bouquets FROM packages pa WHERE pa.id=12) THEN 'HD'
	END as Type,
    CASE 
		WHEN us.is_e2=1 && us.is_mag=0 THEN 'ENIGMA'
		WHEN us.is_e2=0 && us.is_mag=1 THEN 'MAG'
        WHEN us.is_e2=0 && us.is_mag=0 THEN 'NORMAL'
	END as Type
FROM
  users us
LEFT JOIN user_activity_now uan ON uan.user_id=us.id
INNER JOIN reg_users ru ON ru.id = ruid_int && ru.id=us.created_by && ru.member_group_id=5
LEFT JOIN nobrain_middleware.activeCode act
	ON act.idClient=us.id
LEFT JOIN
	nobrain_middleware.infolines infL
		ON infL.idlines=act.idClient
GROUP BY us.id
ORDER BY channelIcon DESC;
END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `getListPackageRev` */;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `getListPackageRev`(
idrev_in INT
)
BEGIN
	SELECT
		en.listPackage
	FROM
		nobrain_middleware.resellerOffer en
	WHERE
		en.idRev=idrev_in;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `getListSmartIPTV` */;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET utf8 COLLATE utf8_unicode_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `getListSmartIPTV`()
BEGIN
	SELECT
		sm.macadress,
        sm.activecode
    FROM
		nobrain_middleware.smartiptv sm
	WHERE
		sm.status=0;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `getMagById` */;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET utf8 COLLATE utf8_unicode_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `getMagById`(
idLine_in INT,
idReg_in INT,
memberGroup_in INT
)
BEGIN
	IF memberGroup_in=5 THEN
		SELECT 
			md.mag_id,
			md.stb_type,
			md.mac,
			CASE
				WHEN us.exp_date is null THEN 'UNLIMITED'
				WHEN us.exp_date is not null THEN from_unixtime(us.exp_date)
			END as DateExpire,
			infL.firstname,
			infL.familyname,
			infL.phone,
			infL.email,
			us.reseller_notes
		FROM
			users us
		LEFT JOIN
			mag_devices md
				ON md.user_id=us.id
		LEFT JOIN
			nobrain_middleware.infolines infL
				ON infL.idlines=us.id
		WHERE
			us.created_by=idReg_in && us.id=idLine_in;
		
        ELSE
        IF memberGroup_in=1 THEN
			SELECT 
				md.mag_id,
				md.stb_type,
				md.mac,
				CASE
					WHEN us.exp_date is null THEN 'UNLIMITED'
					WHEN us.exp_date is not null THEN from_unixtime(us.exp_date)
				END as DateExpire,
				infL.firstname,
				infL.familyname,
				infL.phone,
				infL.email,
				us.reseller_notes
			FROM
				users us
			LEFT JOIN
				mag_devices md
					ON md.user_id=us.id
			LEFT JOIN
				nobrain_middleware.infolines infL
					ON infL.idlines=us.id
			WHERE
				us.id=idLine_in;
        END IF;
	END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `getNumberChangeAct` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `getNumberChangeAct`(
idline_in INT,
idreg_in INT,
membergr_in INT
)
BEGIN
	IF membergr_in=5 THEN
		SELECT
			inf.limitchangeact
		FROM
			nobrain_middleware.infolines inf
		INNER JOIN
			users us
			ON us.id=inf.idlines && us.created_by=idreg_in && us.id=idline_in;
	END IF;
    IF membergr_in=1 THEN
		SELECT
			inf.limitchangeact
		FROM
			nobrain_middleware.infolines inf
		INNER JOIN
			users us
			ON us.id=inf.idlines && us.id=idline_in;
	END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getOrderCat` */;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `getOrderCat`()
BEGIN
	SELECT
		stc.id as nameCat,
		(SELECT COUNT(str.id) FROM streams str WHERE str.category_id=stc.id GROUP BY stc.id) as totalChannel,
        ((COUNT(sts.stream_id))*100)/(SELECT COUNT(str.id) FROM streams str WHERE str.category_id=stc.id GROUP BY stc.id) as Moy
	FROM 
		xtream_iptvpro.stream_categories stc
	INNER JOIN streams st
		ON st.category_id=stc.id
	INNER JOIN streams_sys sts
		ON sts.stream_id=st.id
	WHERE
		sts.pid <> -1 && st.type=1
	GROUP BY
		stc.id
	ORDER BY Moy DESC,nameCat ASC;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `getPackageInfoRev` */;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `getPackageInfoRev`(
idPackage_in INT
)
BEGIN
SELECT 
	id,
	package_name,
	is_official,
	official_credits,
	official_duration,
	official_duration_in,
	bouquets 
FROM 
	packages
WHERE
	id=idPackage_in;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `getPackageLine` */;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET utf8 COLLATE utf8_unicode_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `getPackageLine`(
idline_in INT
)
BEGIN
	DECLARE bouquetType mediumtext DEFAULT '';
    DECLARE bouqetHD LONGTEXT;
	DECLARE bouqetSD LONGTEXT;
	
	SELECT
		us.bouquet
	INTO
		bouquetType
    FROM
		xtream_iptvpro.users us
	WHERE
		us.id=idline_in;
        
	
		SELECT 
			pa.id,
			pa.package_name,
			pa.is_official,
			pa.official_credits,
			pa.official_duration,
			pa.official_duration_in,
			pa.bouquets 
        FROM 
			packages pa
		WHERE
			pa.bouquets=bouquetType;
    

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `getResellerById` */;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET utf8 COLLATE utf8_unicode_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `getResellerById`(
ownerid_in INT,
resellerid_in INT,
memberGroup_in INT
)
BEGIN
	IF memberGroup_in=5 THEN
		SELECT
			ru.username,
			infr.fristname,
			infr.familyname,
			infr.phone,
			ru.email
		FROM
			nobrain_middleware.inforeseller infr
		INNER JOIN
			xtream_iptvpro.reg_users ru
				ON ru.id=infr.idreg
		WHERE
			ru.owner_id=ownerid_in && ru.id=resellerid_in;
            
	ELSE
		SELECT
			ru.username,
			infr.fristname,
			infr.familyname,
			infr.phone,
			ru.email
		FROM
			nobrain_middleware.inforeseller infr
		INNER JOIN
			xtream_iptvpro.reg_users ru
				ON ru.id=infr.idreg
		WHERE
			ru.id=resellerid_in;
	END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `getSettings` */;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET utf8 COLLATE utf8_unicode_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `getSettings`()
BEGIN
	SELECT
    st.nameServer, 
    st.email, 
    st.logo, 
    st.facebookpage,  
    st.twitterpage,
    st.instagrampage,
	st.xtreampage
    FROM 
		nobrain_middleware.settings st;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `getStreamsCat` */;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET utf8 COLLATE utf8_unicode_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `getStreamsCat`(
idcat_in INT,
stats_in INT
)
BEGIN
	IF stats_in = 1 THEN
		SELECT
			CONCAT(',"',st.id,'"')
		FROM 
			xtream_iptvpro.streams st
		INNER JOIN
			streams_sys sts
			ON sts.stream_id=st.id AND (sts.current_source IS NOT NULL AND sts.pid <> -1)
		WHERE
			st.category_id=idcat_in
		ORDER BY
			st.stream_display_name ASC;
	END IF;
    IF stats_in = 0 THEN
		SELECT
			CONCAT(',"',st.id,'"')
		FROM 
			xtream_iptvpro.streams st
		INNER JOIN
			streams_sys sts
			ON sts.stream_id=st.id AND (sts.current_source IS NOT NULL)
		WHERE
			st.category_id=idcat_in
		ORDER BY
			st.stream_display_name ASC;
    END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `getSubReseller` */;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `getSubReseller`(
idreg_in INT,
membergroup_in INT
)
BEGIN
IF membergroup_in=5 THEN
SELECT
	CASE
		WHEN ru.status=1 THEN 'ENABLED'
        WHEN ru.status=0 THEN 'DISABLED'
    END as state,
    infr.fristname,
    infr.familyname,
    ru.username,
        (SELECT COUNT(us.id) FROM users us INNER JOIN nobrain_middleware.activeCode inf ON inf.idClient=us.id WHERE us.created_by=ru.id && inf.active=1) as TotalLine,
	infr.phone,
    rl.Months12 as Months12,
    rl.Months6 as Months6,
    rl.Months1 as Months1,
    rl.Days1 as Test,
    ru.id,
    (SELECT COUNT(inf.idClient) FROM users us INNER JOIN nobrain_middleware.activeCode inf ON inf.idClient=us.id WHERE inf.active=1  && us.created_by=ru.id && inf.duree='12 months') as TotalLineGold,
    (SELECT COUNT(us.id) FROM users us INNER JOIN nobrain_middleware.activeCode inf ON inf.idClient=us.id WHERE inf.active=1  && us.created_by=ru.id && inf.duree='6 months') as TotalLineSilver,
    (SELECT COUNT(us.id) FROM users us INNER JOIN nobrain_middleware.activeCode inf ON inf.idClient=us.id WHERE inf.active=1  && us.created_by=ru.id && inf.duree='1 months') as TotalLineBronze,
    (SELECT COUNT(us.id) FROM users us INNER JOIN nobrain_middleware.activeCode inf ON inf.idClient=us.id WHERE inf.active=1  && us.created_by=ru.id && inf.duree='1 days') as TotalLine1D,
    rl.SD12 as SD12,
    rl.SD6 as SD6,
    rl.SD1 as SD6,
    rl.SDAYS1 as SDAYS1
FROM 
	reg_users ru
INNER JOIN
	nobrain_middleware.inforeseller infr
		ON infr.idreg=ru.id
LEFT JOIN
	nobrain_middleware.revendeurLimit rl
		ON rl.idReg=ru.id
WHERE ru.owner_id=idreg_in;
END IF;
IF membergroup_in=1 THEN
SELECT
	CASE
		WHEN ru.status=1 THEN 'ENABLED'
        WHEN ru.status=0 THEN 'DISABLED'
    END as state,
    infr.fristname,
    infr.familyname,
    ru.username,
        (SELECT COUNT(us.id) FROM users us INNER JOIN nobrain_middleware.activeCode inf ON inf.idClient=us.id WHERE us.created_by=ru.id && inf.active=1) as TotalLine,
	infr.phone,
    rl.Months12 as Months12,
    rl.Months6 as Months6,
    rl.Months1 as Months1,
    rl.Days1 as Test,
    ru.id,
    (SELECT COUNT(inf.idClient) FROM users us INNER JOIN nobrain_middleware.activeCode inf ON inf.idClient=us.id WHERE inf.active=1  && us.created_by=ru.id && inf.duree='12 months') as TotalLineGold,
    (SELECT COUNT(us.id) FROM users us INNER JOIN nobrain_middleware.activeCode inf ON inf.idClient=us.id WHERE inf.active=1  && us.created_by=ru.id && inf.duree='6 months') as TotalLineSilver,
    (SELECT COUNT(us.id) FROM users us INNER JOIN nobrain_middleware.activeCode inf ON inf.idClient=us.id WHERE inf.active=1  && us.created_by=ru.id && inf.duree='1 months') as TotalLineBronze,
    (SELECT COUNT(us.id) FROM users us INNER JOIN nobrain_middleware.activeCode inf ON inf.idClient=us.id WHERE inf.active=1  && us.created_by=ru.id && inf.duree='1 days') as TotalLine1D,
    rl.SD12 as SD12,
    rl.SD6 as SD6,
    rl.SD1 as SD6,
    rl.SDAYS1 as SDAYS1
FROM 
	reg_users ru
INNER JOIN
	nobrain_middleware.inforeseller infr
		ON infr.idreg=ru.id
LEFT JOIN
	nobrain_middleware.revendeurLimit rl
		ON rl.idReg=ru.id;
END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `getTicket` */;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `getTicket`(
iduser_in INT,
idowner_in INT
)
BEGIN
SELECT
	CASE
		WHEN ti.admin_read=0 && ti.user_read=1 && tr.admin_reply=0 THEN 'No Answer'
        WHEN ti.admin_read=1 && ti.user_read=0 && tr.admin_reply=1 THEN 'Answred'
        WHEN ti.admin_read=1 && ti.user_read=1 && tr.admin_reply=0 THEN 'No Answer'
        WHEN ti.admin_read=1 && ti.user_read=0 && tr.admin_reply=0 THEN 'No Answer'
    END as statu,
    ru.username,
    ti.title,
    from_unixtime(tr.date) as dateReclamation,
    ti.id,
    ti.status
FROM
	tickets ti
INNER JOIN
	tickets_replies tr
		ON tr.ticket_id=ti.id
INNER JOIN
	reg_users ru
		ON ru.id=ti.member_id && ti.member_id=iduser_in
UNION ALL
SELECT
	CASE
		WHEN ti.admin_read=0 && ti.user_read=1 && tr.admin_reply=0 THEN 'No Answer'
        WHEN ti.admin_read=1 && ti.user_read=0 && tr.admin_reply=1 THEN 'Answred'
        WHEN ti.admin_read=1 && ti.user_read=1 && tr.admin_reply=0 THEN 'No Answer'
        WHEN ti.admin_read=1 && ti.user_read=0 && tr.admin_reply=0 THEN 'No Answer'
    END as statu,
    ru.username,
    ti.title,
    from_unixtime(tr.date) as dateReclamation,
    ti.id,
    ti.status
FROM
	tickets ti
INNER JOIN
	tickets_replies tr
		ON tr.ticket_id=ti.id
INNER JOIN
	reg_users ru
		ON ru.id=ti.member_id
WHERE  ru.owner_id=iduser_in
ORDER BY dateReclamation DESC;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `getTrialActiveCode` */;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `getTrialActiveCode`(
ip_in mediumtext
)
BEGIN
	DECLARE checke INT DEFAULT 0;
    DECLARE acte mediumtext;
    
    SELECT
		iac.id
	INTO
		checke
	FROM
		nobrain_middleware.ipActiveCode iac
	WHERE
		iac.ip=ip_in;
    
    IF checke = 0 THEN
		SELECT
			aC.numberCode
		INTO
			acte
		FROM
			nobrain_middleware.activeCode aC
		INNER JOIN
			xtream_iptvpro.users us
				ON us.id=aC.idClient && us.created_by=208 && aC.active=0 && aC.duree='1 days'
		LIMIT 1;
		
        INSERT INTO
			nobrain_middleware.ipActiveCode(activecode, ip)
        VALUE
			(acte,ip_in);
            
		CALL xtream_iptvpro.checkLineGet(acte);
        IF CHAR_LENGTH(acte) = 15 THEN
			SELECT acte;
        END IF;
	END IF;
    IF checke <> 0 THEN
		SELECT
			ipA.activecode
        FROM
			nobrain_middleware.ipActiveCode ipA
		WHERE
			ipA.id=checke;
    END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `getVODName` */;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `getVODName`()
BEGIN
	SELECT 
		st.stream_icon,
        st.stream_display_name as nomVOD
    FROM 
		xtream_iptvpro.streams st
    WHERE 
		st.category_id IS NOT NULL && st.type=2
    ORDER BY 
		nomVOD ASC;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `lockTicket` */;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `lockTicket`(
idticket_in INT,
iduser_in INT
)
BEGIN
	DECLARE stateTicket INT DEFAULT NULL;
	
	SELECT
		ti.status
	INTO
		stateTicket
    FROM
		xtream_iptvpro.tickets ti
	INNER JOIN
			xtream_iptvpro.reg_users ru
				ON ti.member_id=ru.id
	WHERE
		(ti.member_id=iduser_in OR ru.owner_id=iduser_in) && ti.id=idticket_in;
    
	IF stateTicket = 1 THEN
		UPDATE
			xtream_iptvpro.tickets tie
		INNER JOIN
			xtream_iptvpro.reg_users ru
				ON tie.member_id=ru.id
		SET
			tie.status=0
		WHERE
			tie.id=idticket_in && (tie.member_id=iduser_in OR ru.owner_id=iduser_in);
	END IF;
    
    SELECT stateTicket;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `MagToLine` */;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `MagToLine`(
idreg_in INT,
idmag_in INT
)
BEGIN
	DECLARE idn INT DEFAULT 0;
	SELECT
		us.id
	INTO
		idn
	FROM
		users us
	INNER JOIN
		mag_devices mg
			ON mg.user_id=us.id && mg.mag_id=idmag_in
	WHERE
		us.member_id=idreg_in;
	
    IF idn <> 0 THEN
		UPDATE
			users us
		SET
			us.is_mag=0,
            us.is_e2=0
		WHERE
			us.id=idn;
            
		DELETE mg FROM
			mag_devices mg
		WHERE
			mg.mag_id=idmag_in && mg.user_id=idn;
    END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `restartChannel` */;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `restartChannel`(
idCh_in INT
)
BEGIN
		SET SQL_SAFE_UPDATES = 0;

	UPDATE streams_sys sys
    INNER JOIN
		streams st
			ON st.id=sys.stream_id
	SET
		sys.pid=456246
	WHERE
		st.id=idCh_in;
        	SET SQL_SAFE_UPDATES = 1;


END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `setSettings` */;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET utf8 COLLATE utf8_unicode_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `setSettings`(
nameserver_in varchar(200),
email_in varchar(200),
logo_in varchar(200),
facebook_in varchar(255),
twitter_in varchar(255),
instagram_in varchar(255),
xtream_in varchar(255)
)
BEGIN
	UPDATE 
		nobrain_middleware.settings 
	SET 
		nameServer=nameserver_in,
        email=email_in,
        logo=logo_in,
        facebookpage=facebook_in,
        twitterpage=twitter_in,
        instagrampage=instagram_in,
        xtreampage=xtream_in
	WHERE 
		id=1;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `updateAccount` */;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `updateAccount`(
gold_in INT,
silver_in INT,
bronze_in INT,
idregus_in INT,
idregusowner_in INT
)
BEGIN
	DECLARE GoldAct INT;
    DECLARE SilverAct INT;
    DECLARE BronzeAct INT;
    DECLARE OneDAct INT;
    
	SELECT
		rL.Months12,
        rL.Months6,
        rL.Months1,
        rL.Days1
	INTO
		GoldAct,SilverAct,BronzeAct,OneDAct
	FROM
		nobrain_middleware.revendeurLimit rL
	WHERE
		rL.idReg=idregusowner_in;
        
	IF (GoldAct>=gold_in) && (SilverAct>=silver_in) && (BronzeAct>=bronze_in) THEN
		UPDATE nobrain_middleware.revendeurLimit
		SET Months12=Months12+gold_in,Months6=Months6+silver_in,Months1=Months1+bronze_in,Days1=Days1+(ceil(gold_in/220)+ceil(silver_in/80)+ceil(bronze_in/20))
		WHERE idReg=idregus_in;
        
        UPDATE nobrain_middleware.revendeurLimit
		SET Months12=Months12-gold_in,Months6=Months6-silver_in,Months1=Months1-bronze_in
		WHERE idReg=idregusowner_in;
    END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `updateChannelM` */;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET utf8 COLLATE utf8_unicode_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `updateChannelM`(
nomch_in VARCHAR(255),
oldname_in VARCHAR(255)
)
BEGIN
	SET SQL_SAFE_UPDATES=0;
	UPDATE
		streams st
	SET
		st.stream_display_name=nomch_in
	WHERE
		st.stream_display_name = oldname_in;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `updateCredits` */;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET utf8 COLLATE utf8_unicode_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `updateCredits`(	
    credit_in INT,
    idRegUsers_in INT,
    idPackage_in INT
)
BEGIN
    CASE idPackage_in
		WHEN 8 THEN UPDATE nobrain_middleware.revendeurLimit SET Months12=Months12-credit_in WHERE idReg=idRegUsers_in;
		WHEN 9 THEN UPDATE nobrain_middleware.revendeurLimit SET Months6=Months6-credit_in WHERE idReg=idRegUsers_in;
        WHEN 10 THEN UPDATE nobrain_middleware.revendeurLimit SET Months3=Months3-credit_in WHERE idReg=idRegUsers_in;
		WHEN 11 THEN UPDATE nobrain_middleware.revendeurLimit SET Months1=Months1-credit_in WHERE idReg=idRegUsers_in;
		WHEN 12 THEN UPDATE nobrain_middleware.revendeurLimit SET Days1=Days1-credit_in WHERE idReg=idRegUsers_in;
        
		WHEN 13 THEN UPDATE nobrain_middleware.revendeurLimit SET SD12=SD12-credit_in WHERE idReg=idRegUsers_in;
		WHEN 14 THEN UPDATE nobrain_middleware.revendeurLimit SET SD6=SD6-credit_in WHERE idReg=idRegUsers_in;
		WHEN 15 THEN UPDATE nobrain_middleware.revendeurLimit SET SMonths3=SMonths3-credit_in WHERE idReg=idRegUsers_in;
        WHEN 16 THEN UPDATE nobrain_middleware.revendeurLimit SET SD1=SD1-credit_in WHERE idReg=idRegUsers_in;
		WHEN 17 THEN UPDATE nobrain_middleware.revendeurLimit SET SDAYS1=SDAYS1-credit_in WHERE idReg=idRegUsers_in;
        
	END CASE;
    
    UPDATE
		nobrain_middleware.revendeurAccount rA
	SET
		rA.totalAccount=rA.totalAccount-credit_in
	WHERE
		rA.idRev=idRegUsers_in && rA.idPackage=idPackage_in;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `updateCredits12` */;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `updateCredits12`(
    credit_in INT,
    idRegUsers_in INT
)
BEGIN
UPDATE
	nobrain_middleware.revendeurLimit
SET
	Months12=Months12-credit_in
WHERE
	idReg=idRegUsers_in;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `updateCredits1D` */;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `updateCredits1D`(
    idRegUsers_in INT
)
BEGIN
UPDATE
	nobrain_middleware.revendeurLimit
SET
	Days1=Days1-1
WHERE
	idReg=idRegUsers_in;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `updateCredits1M` */;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `updateCredits1M`(
    credit_in INT,
    idRegUsers_in INT
)
BEGIN
UPDATE
	nobrain_middleware.revendeurLimit
SET
	Months1=Months1-credit_in
WHERE
	idReg=idRegUsers_in;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `updateCredits6` */;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `updateCredits6`(
    credit_in INT,
    idRegUsers_in INT
)
BEGIN
UPDATE
	nobrain_middleware.revendeurLimit
SET
	Months6=Months6-credit_in
WHERE
	idReg=idRegUsers_in;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `updateCreditsRegUsers` */;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET utf8 COLLATE utf8_unicode_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `updateCreditsRegUsers`(
username_in INT,
idregOwner_in INT,
HD12 INT,
HD6 INT,
HD1 INT,
HD1D INT,
SD12 INT,
SD6 INT,
SD1 INT,
SD1D INT
)
BEGIN
SET SQL_SAFE_UPDATES = 0;

	UPDATE
		nobrain_middleware.revendeurLimit rl
	SET
		rl.Months12=rl.Months12+HD12,
        rl.Months6=rl.Months6+HD6,
        rl.Months1=rl.Months1+HD1,
		rl.Days1=rl.Days1+(HD1D+HD12+HD6+HD1),
        rl.SD12=rl.SD12+SD12,
        rl.SD6=rl.SD6+SD6,
        rl.SD1=rl.SD1+SD1,
        rl.SDAYS1=rl.SDAYS1+(SD1D+SD12+SD6+SD1)
	WHERE
		rl.idReg=username_in  && HD12 >= 0 && HD6 >= 0 && HD1 >= 0 && SD12 >= 0 && SD6 >= 0 && SD1 >= 0 ;
	
    UPDATE
		nobrain_middleware.revendeurLimit rl
	SET
		rl.Months12=rl.Months12-HD12,
        rl.Months6=rl.Months6-HD6,
        rl.Months1=rl.Months1-HD1,
        rl.Days1=rl.Days1-HD1D,
        rl.SD12=rl.SD12-SD12,
        rl.SD6=rl.SD6-SD6,
        rl.SD1=rl.SD1-SD1,
        rl.SDAYS1=rl.SDAYS1+SD1D
	WHERE
		rl.idReg=idregOwner_in && HD12 >=0 && HD6 >=0 && HD1 >=0 && SD12 >=0 && SD6 >=0 && SD1 >=0;
SET SQL_SAFE_UPDATES = 1;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `updateCreditsRes` */;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `updateCreditsRes`(
	credit12_in INT,
    credit6_in INT,
    credit1_in INT,
    idRegUsers_in INT
)
BEGIN

DECLARE cr12 INT DEFAULT 220;
DECLARE cr6 INT DEFAULT 80;
DECLARE cr1 INT DEFAULT 20;

UPDATE
	nobrain_middleware.revendeurLimit
SET
	Months12=Months12-credit12_in,Months6=Months6-credit6_in,Months1=Months6-credit1_in,Days1=credit12_in+credit6_in+credit1_in
WHERE
	idReg=idRegUsers_in && Months12>0 && Months6>0 && Months1>0;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `updateEnigma` */;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET utf8 COLLATE utf8_unicode_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `updateEnigma`(
id_user_in INT,
mac_in varchar(255),
dateadd_in INT,
idreg_in INT,
firstname_in mediumtext,
familyname_in mediumtext,
email_in mediumtext,
note_in mediumtext,
phone_in mediumtext
)
BEGIN
	DECLARE ide INT DEFAULT 0;
    IF levelUser(idreg_in)=5 THEN
		SELECT 
			us.id
		INTO
			ide
		FROM
			users us
		WHERE
			us.created_by=idreg_in && us.id=id_user_in;
	ELSE
		IF levelUser(idreg_in)=1 THEN
			SELECT 
				us.id
			INTO
				ide
			FROM
				users us
			WHERE
				us.id=id_user_in;
        END IF;
	END IF;
        
	IF ide<>0 THEN
    
		UPDATE users us
		INNER JOIN
			enigma2_devices md
				ON md.user_id=us.id
		LEFT JOIN
			nobrain_middleware.infolines infL
			ON infL.idlines=us.id
		SET
			infL.firstname=firstname_in,
            infL.familyname=familyname_in,
            infL.phone=phone_in,
            md.mac=mac_in,
            us.exp_date=unix_timestamp((DATE_ADD(from_unixtime(us.exp_date), INTERVAL dateadd_in MONTH))),
            infL.email=email_in,
            us.reseller_notes=note_in
		WHERE
			us.id=id_user_in;
	END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `updateLines` */;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET utf8 COLLATE utf8_unicode_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `updateLines`(
id_user_in INT,
dateadd_in INT,
idreg_in INT,
firstname_in mediumtext,
familyname_in mediumtext,
email_in mediumtext,
note_in mediumtext,
phone_in mediumtext,
typeabo_in mediumtext
)
BEGIN
	DECLARE ide INT DEFAULT 0;
    
	SELECT 
		us.id
	INTO
		ide
    FROM
		users us
	WHERE
		us.created_by=idreg_in && us.id=id_user_in;
        
	IF levelUser(idreg_in)=1 THEN
		SELECT 
			us.id
		INTO
			ide
		FROM
			users us
		WHERE
			us.id=id_user_in;
    END IF;
        
	IF ide<>0 THEN
		UPDATE users us
			LEFT JOIN
				nobrain_middleware.infolines infL
					ON infL.idlines=us.id
			SET
				infL.firstname=firstname_in,
                infL.familyname=familyname_in,
                infL.phone=phone_in,
                infL.email=email_in,
                us.reseller_notes=note_in
			WHERE
				us.id=id_user_in;
                
                
		IF typeabo_in LIKE '% days' THEN
			UPDATE users us
			LEFT JOIN
				nobrain_middleware.infolines infL
					ON infL.idlines=us.id
			SET
                us.exp_date=unix_timestamp((DATE_ADD(from_unixtime(exp_date), INTERVAL 0 DAY)))
			WHERE
				us.id=id_user_in;
		END IF;
        IF typeabo_in LIKE '% months' THEN
			UPDATE users us
			LEFT JOIN
				nobrain_middleware.infolines infL
					ON infL.idlines=us.id
			SET
                us.exp_date=unix_timestamp((DATE_ADD(from_unixtime(exp_date), INTERVAL dateadd_in MONTH)))
			WHERE
				us.id=id_user_in;
		END IF;
	END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `updateMags` */;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET utf8 COLLATE utf8_unicode_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `updateMags`(
id_user_in INT,
mac_in varchar(255),
dateadd_in INT,
idreg_in INT,
firstname_in mediumtext,
familyname_in mediumtext,
email_in mediumtext,
note_in mediumtext,
phone_in mediumtext
)
BEGIN
	DECLARE ide INT DEFAULT 0;
	SELECT 
		us.id
	INTO
		ide
    FROM
		users us
	WHERE
		us.created_by=idreg_in && us.id=id_user_in && us.is_mag=1;
        
	IF levelUser(idreg_in)=1 THEN
		SELECT 
			us.id
		INTO
			ide
		FROM
			users us
		WHERE
			us.id=id_user_in;
    END IF;
        
	IF ide<>0 THEN
		UPDATE users us
		INNER JOIN
			mag_devices md
				ON md.user_id=us.id
		LEFT JOIN
			nobrain_middleware.infolines infL
			ON infL.idlines=us.id
		SET
			infL.firstname=firstname_in,
            infL.familyname=familyname_in,
            infL.email=email_in,
            us.reseller_notes=note_in,
            infL.phone=phone_in,
            md.mac=mac_in,
            us.exp_date=unix_timestamp((DATE_ADD(from_unixtime(us.exp_date), INTERVAL dateadd_in MONTH)))
		WHERE
			us.id=id_user_in;
	END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `updateName` */;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `updateName`(
oldname_in mediumtext,
newname_in mediumtext
)
BEGIN
SET SQL_SAFE_UPDATES=0;
	UPDATE
		streams
	SET
		stream_display_name=newname_in
	WHERE
		stream_display_name=oldname_in;
SET SQL_SAFE_UPDATES=1;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `updateRegUsersLogin` */;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `updateRegUsersLogin`(
idreg_in INT,
ip_in varchar(255),
lastlogin_in varchar(255)
)
BEGIN
	UPDATE reg_users
    SET
		ip=ip_in,last_login=unix_timestamp(lastlogin_in)
    WHERE
		id=idreg_in;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `upperCh` */;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `upperCh`()
BEGIN
SET SQL_SAFE_UPDATES=0;
	UPDATE
		streams
	SET
		stream_display_name=upper(stream_display_name);
SET SQL_SAFE_UPDATES=1;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `verifActiveCode` */;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `verifActiveCode`(
act_in MEDIUMTEXT
)
BEGIN
	SELECT
		us.enabled as state,
		from_unixtime(us.created_at) as createDate,
        from_unixtime(us.exp_date) as expDate,
        us.is_mag,
        us.is_e2,
        CASE 
			WHEN us.bouquet=(SELECT pa.bouquets FROM packages pa WHERE pa.id=8) THEN 'FULL HD'
            WHEN us.bouquet=(SELECT pa.bouquets FROM packages pa WHERE pa.id=12) THEN 'HD'
        END as Type
    FROM
		nobrain_middleware.activeCode acT
	INNER JOIN
		xtream_iptvpro.users us
        ON us.id=acT.idClient
	WHERE
		acT.numberCode=act_in;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `xtream_iptvpro` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;